﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Student student;

        public Form1()
        {
            InitializeComponent();
            student = new Student();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Работа с классом студент";
            button1.Text = "Рассчет веса";
            label1.Text = "Фамилия имя";
            label2.Text = "Рост";
            label3.Text = "Вес";
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            student.name = textBox1.Text;
            student.rost = (int)numericUpDown1.Value;
            double eda = 1; // Значение параметра eda (количество съеденной еды)

            // Рассчет веса, если студент съел 1 кг
            student.SetEat(eda);

            MessageBox.Show(string.Format("Студент: {0}\nРост: {1} см\nВес: {2} кг",
                student.name, student.rost, student.GetEat()));

            eda = 5; // Изменяем значение параметра eda на 5 кг

            // Рассчет веса, если студент съел 5 кг
            student.SetEat(eda);

            MessageBox.Show(string.Format("Студент: {0}\nРост: {1} см\nВес: {2} кг",
                student.name, student.rost, student.GetEat()));
        }
    }

    public class Student
    {
        public string name { get; set; }
        public int rost { get; set; }
        private double ves;

        public double GetEat()
        {
            return ves;
        }

        public void SetEat(double eda)
        {
            if (eda > 10)
            {
                rost -= 2;
                ves += (eda * 1000 - 1800) * 0.5;
            }
            else if (eda > 5)
            {
                rost -= 1;
                ves += (eda * 1000 - 1600) * 0.7;
            }
            else
            {
                ves += eda * 1000;
            }
        }
    }
}
